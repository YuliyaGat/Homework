import mymod as my
my.test('biography_Kilian_Jornet.txt')
my.test('mymod.py')

from mymod import test
test('biography_Kilian_Jornet.txt')
test('mymod.py')