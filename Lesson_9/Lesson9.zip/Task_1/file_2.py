from file_1 import function_1
function_1('Bill')