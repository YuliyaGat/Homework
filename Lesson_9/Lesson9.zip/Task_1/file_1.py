def function_1(name):
    print('Hello ', name, '!', sep='')
